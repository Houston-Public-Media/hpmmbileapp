// src/contexts/ListenLiveContext.tsx

import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { listenLiveService } from '../services/ListenLiveServices';

interface Track {
  id: string;
  title: string;
  artist: string;
  album?: string;
  artwork?: string;
  url: string;
}

interface ListenLiveContextType {
  isPlayerReady: boolean;
  tracks: Track[];
  error: string | null;
  isLoading: boolean;
  refreshListenLiveData: () => Promise<void>;
}

const ListenLiveContext = createContext<ListenLiveContextType | undefined>(undefined);

interface ListenLiveProviderProps {
  children: ReactNode;
}

export const ListenLiveProvider: React.FC<ListenLiveProviderProps> = ({ children }) => {
  const [isPlayerReady, setIsPlayerReady] = useState(false);
  const [tracks, setTracks] = useState<Track[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  const initializeListenLiveService = async () => {
    try {
      setIsLoading(true);
      setError(null);
      
      // Initialize the music player service
      const isSetup = await listenLiveService.initialize();
      
      if (isSetup) {
        // Load tracks and preload all audio streams
        const fetchedTracks = await listenLiveService.loadTracks();
        setTracks(fetchedTracks);
        setIsPlayerReady(true);
        //console.log(`ListenLive initialized successfully with ${fetchedTracks.length} tracks`);
      } else {
        setError("Failed to initialize audio service. Please check your device's audio settings.");
      }
    } catch (error) {
      //console.error("ListenLive setup error:", error);
      
      // Provide more specific error messages
      let errorMessage = "Failed to load audio streams. Please try again later.";
      
      if (error instanceof Error) {
        if (error.message.includes('internet') || error.message.includes('connection')) {
          errorMessage = "No internet connection. Please check your network and try again.";
        } else if (error.message.includes('Failed to load any audio streams')) {
          errorMessage = "All audio streams are currently unavailable. Please try again later.";
        } else if (error.message.includes('permission')) {
          errorMessage = "Audio permission denied. Please check your app permissions.";
        }
      }
      
      setError(errorMessage);
    } finally {
      setIsLoading(false);
    }
  };

  const refreshListenLiveData = async () => {
    await initializeListenLiveService();
  };

  useEffect(() => {
    // Initialize audio service on app launch
    initializeListenLiveService();

    // Handle app state changes for better lifecycle management
    // Note: You may want to add AppState listener here for production apps
    
    // Cleanup on unmount (though this should rarely happen for the root provider)
    return () => {
      // Don't cleanup here as other components might still be using the service
      // The service will clean up when the app is terminated
    };
  }, []);

  const value: ListenLiveContextType = {
    isPlayerReady,
    tracks,
    error,
    isLoading,
    refreshListenLiveData,
  };

  return (
    <ListenLiveContext.Provider value={value}>
      {children}
    </ListenLiveContext.Provider>
  );
};

export const useListenLive = (): ListenLiveContextType => {
  const context = useContext(ListenLiveContext);
  if (context === undefined) {
    throw new Error('useListenLive must be used within an ListenLiveProvider');
  }
  return context;
};