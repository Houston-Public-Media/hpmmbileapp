// src/services/ListenLiveServices.ts

import { Audio } from 'expo-av';
import { audio } from '../data/streams.json';

interface Track { 
  id: string;
  title: string;
  artist: string;
  album?: string;
  artwork?: string;
  url: string;
}

interface ApiTrack {
  id: number;
  name: string;
  artwork: string;
  aacSource: string;
  mp3Source?: string;
}

interface ListenLiveState {
  currentTrackId: string | null;
  isPlaying: boolean;
  isLoading: boolean;
  sound: Audio.Sound | null;
  loadedTracks: Map<string, Audio.Sound>;
  actuallyPlaying: boolean; // Real playback status
}

class ListenLiveService {
  private state: ListenLiveState = {
    currentTrackId: null,
    isPlaying: false,
    isLoading: false,
    sound: null,
    loadedTracks: new Map(),
    actuallyPlaying: false,
  };

  private isInitialized = false;
  private stateChangeListeners: Set<() => void> = new Set();
  private cachedTracks: Track[] = [];

  async initialize(): Promise<boolean> {
    if (this.isInitialized) return true;

    try {
      // Configure audio mode for optimal performance
      await Audio.setAudioModeAsync({
        allowsRecordingIOS: false,
        staysActiveInBackground: true,
        playsInSilentModeIOS: true,
        shouldDuckAndroid: true,
        playThroughEarpieceAndroid: false,
      });

      this.isInitialized = true;
      return true;
    } catch (error) {
     // console.error("Error initializing audio player:", error);
      return false;
    }
  }

  async loadTracks(): Promise<Track[]> {
    try {
      // Fetch audio metadata
      const audioResponse = await fetch("https://s3-us-west-2.amazonaws.com/hpmwebv2/assets/nowplay/all.json");
      const audioData = await audioResponse.json();
      // const response = await fetch("https://cdn.houstonpublicmedia.org/assets/streams.json");
      //const playListData: { audio: ApiTrack[] } = {audio: audio as ApiTrack[]};

      const response = await fetch("https://cdn.houstonpublicmedia.org/assets/streams.json");
      const playListData: { audio: ApiTrack[] } = await response.json();

      // Create track objects
      const tracks = playListData.audio.map((track, index) => ({
        id: track.id.toString(),
        title: track.name,
        artist: audioData.radio?.[index]?.artist || '',
        album: audioData.radio?.[index]?.album || '',
        artwork: track.artwork,
        url: track.aacSource || track.mp3Source || '',
      })).filter(track => track.url && track.url.trim() !== '');

      if (tracks.length === 0) {
        throw new Error('No valid tracks found');
      }

      // Cache tracks for later reference
      this.cachedTracks = tracks;

      // Pre-load all audio streams for instant switching
      await this.preloadAllTracks(tracks);

      return tracks;
    } catch (error) {
      //console.error("Error loading tracks:", error);
      throw error;
    }
  }

  private async preloadAllTracks(tracks: Track[]): Promise<void> {
    const loadPromises = tracks.map(async (track) => {
      try {
        const { sound } = await Audio.Sound.createAsync(
          { uri: track.url },
          { shouldPlay: false, isLooping: false },
          this.onPlaybackStatusUpdate.bind(this)
        );
        
        this.state.loadedTracks.set(track.id, sound);
        //console.log(`Successfully preloaded track: ${track.title}`);
      } catch (error) {
       // console.error(`Failed to preload track ${track.id} (${track.title}):`, error);
        // Don't fail the entire loading process for one track
        // Track will be attempted to load again when user tries to play it
      }
    });

    await Promise.allSettled(loadPromises);
    console.log(`Preloaded ${this.state.loadedTracks.size} out of ${tracks.length} tracks`);
    
    // If no tracks were successfully loaded, throw an error
    if (this.state.loadedTracks.size === 0) {
      throw new Error('Failed to load any audio streams. Please check your internet connection.');
    }
  }

  private onPlaybackStatusUpdate(status: any): void {
    if (status.isLoaded) {
      const wasPlaying = this.state.actuallyPlaying;
      this.state.isPlaying = status.isPlaying;
      this.state.actuallyPlaying = status.isPlaying;
      
      // Notify listeners only if actual playback state changed
      if (wasPlaying !== status.isPlaying) {
        this.notifyStateChange();
      }
      
      // Handle errors or interruptions
      if (status.error) {
        console.error('Playback error:', status.error);
        this.state.isPlaying = false;
        this.state.actuallyPlaying = false;
        this.state.isLoading = false;
        this.notifyStateChange();
      }
    } else if (status.error) {
     // console.error('Audio loading error:', status.error);
      this.state.isPlaying = false;
      this.state.actuallyPlaying = false;
      this.state.isLoading = false;
      this.notifyStateChange();
    }
  }

  async playTrack(trackId: string): Promise<void> {
    try {
      // Stop current track first
      await this.stopCurrentTrack();

      let sound = this.state.loadedTracks.get(trackId);
      
      // If track wasn't preloaded or failed to preload, try to load it now
      if (!sound) {
        //console.log(`Track ${trackId} not preloaded, attempting to load now...`);
        
        // Find the track info to get the URL
        const trackUrl = await this.getTrackUrl(trackId);
        if (!trackUrl) {
          throw new Error(`Track ${trackId} URL not found`);
        }
        
        // Set loading state immediately for UI feedback
        this.state.currentTrackId = trackId;
        this.state.isLoading = true;
        this.state.isPlaying = false;
        this.state.actuallyPlaying = false;
        this.notifyStateChange();
        
        // Try to load the track
        const { sound: newSound } = await Audio.Sound.createAsync(
          { uri: trackUrl },
          { shouldPlay: false, isLooping: false },
          this.onPlaybackStatusUpdate.bind(this)
        );
        
        // Cache the newly loaded sound
        this.state.loadedTracks.set(trackId, newSound);
        sound = newSound;
        //console.log(`Successfully loaded track ${trackId} on demand`);
      }

      // Set loading state immediately for UI feedback
      this.state.currentTrackId = trackId;
      this.state.sound = sound;
      this.state.isLoading = true;
      this.state.isPlaying = false;
      this.state.actuallyPlaying = false;
      this.notifyStateChange();

      // Start new track
      await sound.playAsync();
      
      // Verify it's actually playing with timeout
      const status = await this.waitForPlaybackStart(sound, 5000);
      if (status && status.isLoaded && status.isPlaying) {
        this.state.isPlaying = true;
        this.state.actuallyPlaying = true;
       // console.log(`Now playing: ${trackId}`);
      } else {
        //console.log(`Track ${trackId} failed to start playing`);
        this.state.isPlaying = false;
        this.state.actuallyPlaying = false;
        throw new Error('Audio failed to start playing');
      }
      
      this.state.isLoading = false;
      this.notifyStateChange();
    } catch (error) {
      //console.error("Error playing track:", error);
      // Reset state on error
      this.state.currentTrackId = null;
      this.state.sound = null;
      this.state.isPlaying = false;
      this.state.isLoading = false;
      this.state.actuallyPlaying = false;
      this.notifyStateChange();
      throw error;
    }
  }

  async pauseTrack(): Promise<void> {
    try {
      if (this.state.sound && this.state.isPlaying) {
        await this.state.sound.pauseAsync();
        this.state.isPlaying = false;
        this.state.actuallyPlaying = false;
        this.notifyStateChange();
      }
    } catch (error) {
      //console.error("Error pausing track:", error);
      this.state.isPlaying = false;
      this.state.actuallyPlaying = false;
      this.notifyStateChange();
    }
  }

  async stopCurrentTrack(): Promise<void> {
    try {
      if (this.state.sound) {
        // Immediately set playing to false for faster UI feedback
        this.state.isPlaying = false;
        this.state.actuallyPlaying = false;
        this.state.isLoading = false;
        this.notifyStateChange();
        
        // Check if sound is still loaded before trying to stop
        const status = await this.state.sound.getStatusAsync();
        if (status.isLoaded) {
          // Stop without position reset for smoother transitions
          await this.state.sound.stopAsync();
        }
      }
    } catch (error) {
      // Silently handle common stop errors for live streams
      if (error instanceof Error && error.message && error.message.includes('interrupted')) {
        //console.log("Stop operation interrupted (normal for live streams)");
      } else {
        //console.error("Error stopping track:", error);
      }
      this.state.isPlaying = false;
      this.state.actuallyPlaying = false;
      this.state.isLoading = false;
      this.notifyStateChange();
    }
  }

  // Check if current track supports seeking
  private async isSeekable(): Promise<boolean> {
    try {
      if (!this.state.sound) return false;
      
      const status = await this.state.sound.getStatusAsync();
      if (!status.isLoaded) return false;
      
      // Allow seeking if we have a valid duration and current position
      // This covers recorded content, podcasts, and buffered streams
      return status.durationMillis !== undefined && 
             status.durationMillis > 0 && 
             status.positionMillis !== undefined;
    } catch (error) {
      return false;
    }
  }

  // Seek forward by 10 seconds
  async seekForward(): Promise<void> {
    // Set loading state immediately when seeking starts
    const wasPlaying = this.state.isPlaying;
    
    try {
      if (!this.state.sound) return;

      const status = await this.state.sound.getStatusAsync();
      if (!status.isLoaded) return;

      this.state.isLoading = true;
      this.notifyStateChange();

      // Try seeking if we have position info
      if (status.positionMillis !== undefined) {
        let newPosition = status.positionMillis + 10000;
        
        // If we have duration info, respect the bounds
        if (status.durationMillis && status.durationMillis > 0) {
          newPosition = Math.min(newPosition, status.durationMillis);
        }
        
        await this.state.sound.setPositionAsync(newPosition);
        //console.log(`Seeked forward to: ${newPosition}ms`);
        
        // If we were playing before seek, try to resume playback
        if (wasPlaying) {
          try {
            await this.state.sound.playAsync();
            
            // Wait a bit for audio to stabilize
            setTimeout(async () => {
              try {
                const newStatus = await this.state.sound?.getStatusAsync();
                if (newStatus?.isLoaded && newStatus.isPlaying) {
                  // Successfully resumed playback, maintain playing state
                  this.state.isPlaying = true;
                  this.state.actuallyPlaying = true;
                  this.state.isLoading = false;
                  this.notifyStateChange();
                } else {
                  // Failed to resume, but maintain the intended playing state
                  this.state.isLoading = false;
                  this.state.isPlaying = true; // Keep as playing since user was playing before seek
                  this.state.actuallyPlaying = false;
                  this.notifyStateChange();
                }
              } catch (error) {
                this.state.isLoading = false;
                this.state.isPlaying = true; // Keep as playing since user was playing before seek
                this.state.actuallyPlaying = false;
                this.notifyStateChange();
              }
            }, 500);
          } catch (error) {
            console.error("Error resuming after seek:", error);
            this.state.isLoading = false;
            this.state.isPlaying = true; // Keep as playing since user was playing before seek
            this.state.actuallyPlaying = false;
            this.notifyStateChange();
          }
        } else {
          this.state.isLoading = false;
          this.notifyStateChange();
        }
      } else {
        //console.log("Seeking not available - no position info");
        this.state.isLoading = false;
        this.notifyStateChange();
      }
    } catch (error) {
      // Handle seeking errors gracefully
      this.state.isLoading = false;
      if (error instanceof Error && error.message.includes('interrupted')) {
        //console.log("Seek forward interrupted (normal for some streams)");
        // Audio was interrupted, maintain intended state but mark as not actually playing
        this.state.isPlaying = wasPlaying;
        this.state.actuallyPlaying = false;
      } else {
        //console.error("Error seeking forward:", error);
        this.state.isPlaying = wasPlaying;
        this.state.actuallyPlaying = false;
      }
      this.notifyStateChange();
    }
  }

  // Seek backward by 10 seconds
  async seekBackward(): Promise<void> {
    // Set loading state immediately when seeking starts
    const wasPlaying = this.state.isPlaying;
    
    try {
      if (!this.state.sound) return;

      const status = await this.state.sound.getStatusAsync();
      if (!status.isLoaded) return;

      this.state.isLoading = true;
      this.notifyStateChange();

      // Try seeking if we have position info
      if (status.positionMillis !== undefined) {
        const newPosition = Math.max(status.positionMillis - 10000, 0);
        await this.state.sound.setPositionAsync(newPosition);
       // console.log(`Seeked backward to: ${newPosition}ms`);
        
        // If we were playing before seek, try to resume playback
        if (wasPlaying) {
          try {
            await this.state.sound.playAsync();
            
            // Wait a bit for audio to stabilize
            setTimeout(async () => {
              try {
                const newStatus = await this.state.sound?.getStatusAsync();
                if (newStatus?.isLoaded && newStatus.isPlaying) {
                  // Successfully resumed playback, maintain playing state
                  this.state.isPlaying = true;
                  this.state.actuallyPlaying = true;
                  this.state.isLoading = false;
                  this.notifyStateChange();
                } else {
                  // Failed to resume, but maintain the intended playing state
                  this.state.isLoading = false;
                  this.state.isPlaying = true; // Keep as playing since user was playing before seek
                  this.state.actuallyPlaying = false;
                  this.notifyStateChange();
                }
              } catch (error) {
                this.state.isLoading = false;
                this.state.isPlaying = true; // Keep as playing since user was playing before seek
                this.state.actuallyPlaying = false;
                this.notifyStateChange();
              }
            }, 500);
          } catch (error) {
            //console.error("Error resuming after seek:", error);
            this.state.isLoading = false;
            this.state.isPlaying = true; // Keep as playing since user was playing before seek
            this.state.actuallyPlaying = false;
            this.notifyStateChange();
          }
        } else {
          this.state.isLoading = false;
          this.notifyStateChange();
        }
      } else {
        //console.log("Seeking not available - no position info");
        this.state.isLoading = false;
        this.notifyStateChange();
      }
    } catch (error) {
      // Handle seeking errors gracefully
      this.state.isLoading = false;
      if (error instanceof Error && error.message.includes('interrupted')) {
        //console.log("Seek backward interrupted (normal for some streams)");
        // Audio was interrupted, maintain intended state but mark as not actually playing
        this.state.isPlaying = wasPlaying;
        this.state.actuallyPlaying = false;
      } else {
        //console.error("Error seeking backward:", error);
        this.state.isPlaying = wasPlaying;
        this.state.actuallyPlaying = false;
      }
      this.notifyStateChange();
    }
  }

  async togglePlayPause(trackId: string): Promise<void> {
    // Don't allow new actions while loading
    if (this.state.isLoading) {
      //console.log('Already loading, ignoring toggle request');
      return;
    }

    if (this.state.currentTrackId === trackId) {
      if (this.state.isPlaying) {
        await this.pauseTrack();
      } else {
        // Resume playing the same track
        if (this.state.sound) {
          this.state.isLoading = true;
          this.notifyStateChange();
          
          try {
            await this.state.sound.playAsync();
            const status = await this.state.sound.getStatusAsync();
            this.state.isPlaying = status.isLoaded && status.isPlaying;
            this.state.actuallyPlaying = this.state.isPlaying;
          } catch (error) {
            //console.error('Error resuming track:', error);
            this.state.isPlaying = false;
            this.state.actuallyPlaying = false;
          }
          
          this.state.isLoading = false;
          this.notifyStateChange();
        } else {
          await this.playTrack(trackId);
        }
      }
    } else {
      await this.playTrack(trackId);
    }
  }

  getCurrentState(): ListenLiveState {
    return { ...this.state };
  }

  // Event-driven state management
  addStateChangeListener(callback: () => void): () => void {
    this.stateChangeListeners.add(callback);
    return () => this.stateChangeListeners.delete(callback);
  }

  private notifyStateChange(): void {
    this.stateChangeListeners.forEach(callback => {
      try {
        callback();
      } catch (error) {
        //console.error('Error in state change listener:', error);
      }
    });
  }

  // Helper method to get track URL
  private async getTrackUrl(trackId: string): Promise<string | null> {
    const track = this.cachedTracks.find(t => t.id === trackId);
    return track?.url || null;
  }

  // Helper method to wait for playback to start with timeout
  private async waitForPlaybackStart(sound: Audio.Sound, timeoutMs: number): Promise<any> {
    return new Promise((resolve) => {
      let attempts = 0;
      const maxAttempts = timeoutMs / 100;
      
      const checkStatus = async () => {
        attempts++;
        try {
          const status = await sound.getStatusAsync();
          if (status.isLoaded && status.isPlaying) {
            resolve(status);
          } else if (attempts < maxAttempts) {
            setTimeout(checkStatus, 100);
          } else {
            resolve(null); // Timeout
          }
        } catch (error) {
          resolve(null); // Error
        }
      };
      
      setTimeout(checkStatus, 100); // Start checking after 100ms
    });
  }

  // Public method to check if seeking is available for current track
  async canSeek(): Promise<boolean> {
    return await this.isSeekable();
  }

  async cleanup(): Promise<void> {
    try {
      await this.stopCurrentTrack();
      
      // Unload all tracks
      for (const [trackId, sound] of this.state.loadedTracks) {
        try {
          await sound.unloadAsync();
        } catch (error) {
          //console.error(`Error unloading track ${trackId}:`, error);
        }
      }
      
      this.state.loadedTracks.clear();
      this.state.currentTrackId = null;
      this.state.sound = null;
      this.state.isPlaying = false;
      this.state.isLoading = false;
      this.state.actuallyPlaying = false;
      
      // Clear listeners
      this.stateChangeListeners.clear();
    } catch (error) {
     // console.error("Error during cleanup:", error);
    }
  }
}

// Export singleton instance
export const listenLiveService = new ListenLiveService();

// Legacy functions for backward compatibility
export async function setupPlayer(): Promise<boolean> {
  return listenLiveService.initialize();
}

export async function addTrack(): Promise<Track[]> {
  return listenLiveService.loadTracks();
}

export async function playbackService(): Promise<void> {
  //console.log('Playback service initialized');
}