import React, { useRef, useState } from 'react';
import { View, TouchableOpacity, StyleSheet } from 'react-native';
import { Audio } from 'expo-av';
import { MaterialIcons } from '@expo/vector-icons';
import Slider from '@react-native-community/slider';

interface AudioPlayerProps {
  src: string;
  title: string;
  subtitle: string;
  thumbnail: any; // You can use require() for local images or {uri: '...'} for remote
}

const AudioPlayer: React.FC<AudioPlayerProps> = ({ src, title, subtitle, thumbnail }) => {
  const soundRef = useRef<Audio.Sound | null>(null);
  const [paused, setPaused] = useState(true);
  const [duration, setDuration] = useState(0);
  const [currentTime, setCurrentTime] = useState(0);

  const onPlayPause = async () => {
    if (!soundRef.current) {
      try {
        const { sound } = await Audio.Sound.createAsync({ uri: src });
        soundRef.current = sound;
        await sound.playAsync();
        setPaused(false);
      } catch (error) {
        //console.error('Error loading audio:', error);
      }
    } else {
      if (paused) {
        await soundRef.current.playAsync();
        setPaused(false);
      } else {
        await soundRef.current.pauseAsync();
        setPaused(true);
      }
    }
  };

  const onSeek = async (value: number) => {
    if (soundRef.current) {
      await soundRef.current.setPositionAsync(value);
      setCurrentTime(value);
    }
  };

  return (
    <View style={styles.container}>
      <View style={styles.content}>
        <TouchableOpacity onPress={onPlayPause} style={styles.playButton}>
          <MaterialIcons name={paused ? 'play-arrow' : 'pause'} size={24} color="black" />
        </TouchableOpacity>
        <View style={styles.progressContainer}>
          <Slider
            style={styles.slider}
            minimumValue={0}
            maximumValue={duration}
            value={currentTime}
            thumbImage={require('../assets/icons/transparent.png')}
            minimumTrackTintColor="#4A90E2"
            maximumTrackTintColor="#ccc"
            //thumbTintColor="#ccc"
            onSlidingComplete={onSeek}
          />
          {/* <View style={styles.timeRow}>
            <Text style={styles.timeText}>{formatTime(currentTime)}</Text>
            <Text style={styles.timeText}>{formatTime(duration)}</Text>
          </View> */}
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    width: '100%',
    padding: 20,
    backgroundColor: '#f2f2f2',
    borderRadius: 8,
    marginVertical: 5,
  },
  content: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  playButton: {
    width: 24,
    height: 24,
    borderRadius: 20,
    //backgroundColor: '#4A90E2',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 10,
  },
  progressContainer: {
    flex: 1,
    justifyContent: 'center',
  },
  slider: {
    width: '100%',
    height: 1,
  },
  timeRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  timeText: {
    fontSize: 9,
    color: '#000',
  },
  hidden: {
    width: 0,
    height: 0,
  },
});

export default AudioPlayer;