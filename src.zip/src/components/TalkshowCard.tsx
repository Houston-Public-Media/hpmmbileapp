import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Dimensions } from 'react-native';
import YouTubePlayer from './YouTubePlayer';
import { color } from '../utils/colorUtils';
import { TalkshowEntry } from '../type';

interface TalkshowCardProps {
  talkshow: TalkshowEntry;
  showName: string;
  onPress?: () => void;
}

const TalkshowCard: React.FC<TalkshowCardProps> = ({ 
  talkshow, 
  showName, 
  onPress 
}) => {
  const { live, id, title, description } = talkshow;
  
  const screenWidth = Dimensions.get('window').width;
  const cardPadding = 24;
  const containerMargin = 32;
  const videoWidth = screenWidth - cardPadding - containerMargin;
console.log(description);
  return (
    <TouchableOpacity 
      style={styles.container} 
      onPress={onPress}
      activeOpacity={0.8}
    >
      <View style={styles.header}>
        <View style={styles.titleContainer}>
          <Text style={styles.showName}>{showName}</Text>
          {live && (
            <View style={styles.liveBadge}>
              <Text style={styles.liveText}>LIVE</Text>
            </View>
          )}
        </View>
        {title && (
          <Text style={styles.episodeTitle}>{title}</Text>
        )}
      </View>

      {id && (
        <View style={styles.videoContainer}>
          <YouTubePlayer 
            src={`https://www.youtube.com/watch?v=${id}`}
            width={videoWidth}
            height={200}
          />
        </View>
      )}

      {description && (
        <View style={styles.descriptionContainer}>
          <Text style={styles.description} numberOfLines={32}>
            {description}
          </Text>
        </View>
      )}
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#f9f6f6',
    borderColor: '#bdb9b9',
    borderWidth: 1,
    borderRadius: 8,
    padding: 12,
    marginBottom: 16,
  },
  header: {
    marginBottom: 12,
  },
  titleContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  showName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: color.primary,
    flex: 1,
  },
  liveBadge: {
    backgroundColor: '#ff0000',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 4,
    marginLeft: 8,
  },
  liveText: {
    color: '#ffffff',
    fontSize: 12,
    fontWeight: 'bold',
  },
  episodeTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: color.secondary,
    lineHeight: 20,
  },
  videoContainer: {
    marginBottom: 4,
    borderRadius: 8,
    overflow: 'hidden',
    width: '100%',
    alignItems: 'center',
  },
  descriptionContainer: {
    marginTop: 8,
  },
  description: {
    fontSize: 13,
    color: color.secondary,
    lineHeight: 18,
  },
});

export default TalkshowCard;