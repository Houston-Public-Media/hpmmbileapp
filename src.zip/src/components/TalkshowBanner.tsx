import React, { useEffect, useState, useMemo } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Alert, Linking } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import type { StackNavigationProp } from '@react-navigation/stack';
import { fetchTalkshow } from '../services/newsApi';
import type { TalkshowResponse, TalkshowEntry } from '../type';

const TalkshowBanner: React.FC = () => {
  const navigation = useNavigation<StackNavigationProp<any>>();
  const [talkshows, setTalkshows] = useState<TalkshowResponse['talkshow'] | null>(null);

  useEffect(() => {
    fetchTalkshow().then(setTalkshows);
  }, []);

  const liveTalkshowKey = useMemo(() => {
    if (!talkshows) return null;
    return Object.keys(talkshows).find(key => talkshows[key]?.live);
  }, [talkshows]);

  const { backgroundColor, description, phoneNumber, color } = useMemo(() => {
    switch (liveTalkshowKey) {
      case 'hellohouston': 
        return {
          backgroundColor: '#ff7e27',
          description: 'Hello Houston is on air now!',
          phoneNumber: '7134408870',
          color: '#ffffff', // white text
        };
      case 'houstonmatters':
        return {
          backgroundColor: '#7FFBAD', //3A6F85
          description: 'Houston Matters is on air now!',
          phoneNumber: '7134408870',
          color: '#000000', // light green text 7FFBAD
        };
      default:
        return {
          backgroundColor: '#ccc',
          description: '',
          phoneNumber: '',
          color: '#000000', // fallback to black
        };
    }
  }, [liveTalkshowKey]);


  if (!liveTalkshowKey  || !talkshows?.[liveTalkshowKey]?.id) return null;

  const youtubeUrl = `https://www.youtube.com/watch?v=${talkshows[liveTalkshowKey].id}`;

  return (
    <View style={[styles.banner, { backgroundColor }]}>
      <Text style={[styles.bannerText, { color }]}>
        <Text
          style={styles.link}
          onPress={() => Linking.openURL(youtubeUrl)}
        >
          {description}
        </Text>{' | '}
        <Text
          style={styles.link}
          onPress={() => Linking.openURL(`tel:${phoneNumber}`)}
        >
          Call
        </Text>{' / '}
        <Text
          style={styles.link}
          onPress={() => Linking.openURL(`sms:${phoneNumber}`)}
        >
          Text
        </Text>
      </Text>
    </View>
  );
};

const styles = StyleSheet.create({
  banner: {
    padding: 8,
  },
  bannerText: {
    textAlign: 'center',
    fontWeight: 'bold',
    fontSize: 14,
  },
  link: {
    textDecorationLine: 'underline',
  },
});

export default TalkshowBanner;