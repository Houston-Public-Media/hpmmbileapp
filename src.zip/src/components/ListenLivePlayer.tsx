// src/components/ListenLivePlayer.tsx

import React, {useEffect, useState, useRef} from 'react';
import { FlatList, Image, StyleSheet, Text, TouchableOpacity, View, Alert, Animated} from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { color } from '../utils/colorUtils';
import { listenLiveService } from '../services/ListenLiveServices';

interface Track {
  id: string;
  title: string;
  artist: string;
  artwork?: string;
  url: string;
}

interface ListenLivePlayerProps {
  tracks: Track[];
}

const ListenLivePlayer: React.FC<ListenLivePlayerProps> = ({ tracks }) => {
  const [currentTrackId, setCurrentTrackId] = useState<string | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [canSeek, setCanSeek] = useState(false);
  const rotateAnim = useRef(new Animated.Value(0)).current;

  // Subscribe to player state changes using event-driven approach
  useEffect(() => {
    const updatePlayerState = () => {
      const state = listenLiveService.getCurrentState();
      setCurrentTrackId(state.currentTrackId);
      setIsPlaying(state.isPlaying);
      setIsLoading(state.isLoading);
    };

    // Update seek capability separately and less frequently
    const updateSeekCapability = async (trackId: string | null) => {
      if (trackId) {
        try {
          const seekable = await listenLiveService.canSeek();
          setCanSeek(seekable);
        } catch (error) {
          setCanSeek(false);
        }
      } else {
        setCanSeek(false);
      }
    };

    // Update state immediately
    updatePlayerState();

    // Subscribe to real-time state changes
    const unsubscribe = listenLiveService.addStateChangeListener(updatePlayerState);

    // Set up slower interval for seek capability (less critical)
    const seekInterval = setInterval(() => {
      const state = listenLiveService.getCurrentState();
      updateSeekCapability(state.currentTrackId);
    }, 1000);

    return () => {
      unsubscribe();
      clearInterval(seekInterval);
    };
  }, []);

  // Optimized rotation animation for loading spinner
  useEffect(() => {
    if (isLoading) {
      rotateAnim.setValue(0);
      const animation = Animated.loop(
        Animated.timing(rotateAnim, {
          toValue: 1,
          duration: 1200, // Slightly slower for better UX
          useNativeDriver: true,
        })
      );
      animation.start();
      
      return () => animation.stop();
    } else {
      rotateAnim.setValue(0);
    }
  }, [isLoading, rotateAnim]);

  const onPlayPausePress = async (trackId: string) => {
    try {
      // Don't allow new actions while loading
      if (isLoading) {
        //console.log('Audio is loading, please wait...');
        return;
      }
      
      await listenLiveService.togglePlayPause(trackId);
    } catch (error) {
      //console.error('Error toggling play/pause:', error);
      
      // Provide specific error messages based on the error type
      let errorMessage = 'Unable to play this track. Please try again.';
      
      if (error instanceof Error) {
        if (error.message.includes('network') || error.message.includes('connection')) {
          errorMessage = 'Network error. Please check your internet connection and try again.';
        } else if (error.message.includes('format') || error.message.includes('codec')) {
          errorMessage = 'This audio format is not supported on your device.';
        } else if (error.message.includes('timeout')) {
          errorMessage = 'The stream is taking too long to load. Please try again.';
        } else if (error.message.includes('URL not found')) {
          errorMessage = 'This stream is currently unavailable. Please try another one.';
        }
      }
      
      Alert.alert('Playback Error', errorMessage);
    }
  };

  // Handle seek forward
  const handleSeekForward = async () => {
    if (currentTrackId) {
      try {
        await listenLiveService.seekForward();
      } catch (error) {
       // console.error('Error seeking forward:', error);
      }
    }
  };

  // Handle seek backward
  const handleSeekBackward = async () => {
    if (currentTrackId) {
      try {
        await listenLiveService.seekBackward();
      } catch (error) {
        //console.error('Error seeking backward:', error);
      }
    }
  };

  const renderItem = ({item}: {item: Track}) => {
    const isCurrent = currentTrackId === item.id;
    const isCurrentlyPlaying = isCurrent && isPlaying && !isLoading;
    const isCurrentlyLoading = isCurrent && isLoading;

    return (
      <View style={[
        styles.trackItem,
        isCurrent && styles.currentTrackItem
      ]}>
        <View style={styles.cardLayout}>
          {/* Left section: Artwork */}
          <View style={styles.artworkContainer}>
            {item.artwork ? (
              <Image source={{uri: item.artwork}} style={styles.artwork} />
            ) : (
              <View style={styles.placeholderArtwork}>
                <MaterialIcons name="music-note" size={32} color="#666" />
              </View>
            )}
            {isCurrentlyPlaying && (
              <View style={styles.playingIndicator}>
                <MaterialIcons name="volume-up" size={12} color="#fff" />
              </View>
            )}
            {isCurrentlyLoading && (
              <View style={styles.loadingIndicator}>
                <View style={styles.indicatorIconContainer}>
                  <Animated.View
                    style={{
                      transform: [{
                        rotate: rotateAnim.interpolate({
                          inputRange: [0, 1],
                          outputRange: ['0deg', '360deg'],
                        }),
                      }],
                    }}
                  >
                    <MaterialIcons name="sync" size={12} color="#fff" />
                  </Animated.View>
                </View>
              </View>
            )}
          </View>
          
          {/* Right section: Content area */}
          <View style={styles.rightSection}>
            {/* Top of right: Track Info */}
            <View style={styles.trackInfo}>
              <Text style={[
                styles.title,
                isCurrent && styles.currentTrackTitle
              ]} numberOfLines={2}>
                {item.title}
              </Text>
              <Text style={[
                styles.artist,
                isCurrent && styles.currentTrackArtist
              ]} numberOfLines={1}>
                {item.artist}
              </Text>

            </View>
            
            {/* Bottom of right: Controls */}
            <View style={styles.controlsSection}>
              <TouchableOpacity
                style={[
                  styles.seekButton,
                  (!isCurrent || isCurrentlyLoading) && styles.disabledButton
                ]}
                onPress={handleSeekBackward}
                disabled={!isCurrent || isCurrentlyLoading}
              >
                <MaterialIcons 
                  name="replay-10" 
                  size={18} 
                  color={isCurrent && !isCurrentlyLoading ? (canSeek ? color.primary : '#888') : '#bbb'} 
                />
              </TouchableOpacity>
              
              <TouchableOpacity
                style={[
                  styles.mainPlayButton,
                  isCurrentlyPlaying && styles.pauseButton,
                  isCurrentlyLoading && styles.loadingButton
                ]}
                onPress={() => onPlayPausePress(item.id)}
                activeOpacity={isCurrentlyLoading ? 1 : 0.8}
                disabled={isCurrentlyLoading}
              >
                <View style={styles.buttonIconContainer}>
                  {isCurrentlyLoading ? (
                    <Animated.View
                      style={[
                        styles.iconWrapper,
                        {
                          transform: [{
                            rotate: rotateAnim.interpolate({
                              inputRange: [0, 1],
                              outputRange: ['0deg', '360deg'],
                            }),
                          }],
                        }
                      ]}
                    >
                      <MaterialIcons 
                        name="sync" 
                        size={22} 
                        color="#fff" 
                      />
                    </Animated.View>
                  ) : (
                    <View style={styles.iconWrapper}>
                      <MaterialIcons 
                        name={isCurrentlyPlaying ? 'pause' : 'play-arrow'} 
                        size={22} 
                        color="#fff" 
                      />
                    </View>
                  )}
                </View>
              </TouchableOpacity>
              
              <TouchableOpacity
                style={[
                  styles.seekButton,
                  (!isCurrent || isCurrentlyLoading) && styles.disabledButton
                ]}
                onPress={handleSeekForward}
                disabled={!isCurrent || isCurrentlyLoading}
              >
                <MaterialIcons 
                  name="forward-10" 
                  size={18} 
                  color={isCurrent && !isCurrentlyLoading ? (canSeek ? color.primary : '#888') : '#bbb'} 
                />
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </View>
    );
  };

  return (
    <FlatList
      data={tracks}
      renderItem={renderItem}
      keyExtractor={(item) => item.id}
      contentContainerStyle={styles.listContainer}
    />
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  listContainer: {
    paddingVertical: 4,
    gap: 4,
  },
  trackItem: {
    marginHorizontal: 16,
    marginVertical: 8,
    backgroundColor: '#fff',
    borderRadius: 18,
    padding: 12,
    borderWidth: 2,
    borderColor: 'transparent',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 3,
    },
    shadowOpacity: 0.1,
    shadowRadius: 6,
    elevation: 4,
  },
  cardLayout: {
    flexDirection: 'row',
    alignItems: 'stretch',
  },
  artworkContainer: {
    position: 'relative',
    width: 120,
    height: 120,
    borderRadius: 14,
    overflow: 'hidden',
    marginRight: 16,
    backgroundColor: '#f5f7fa',
  },
  artwork: {
    width: '100%',
    height: '100%',
    resizeMode: 'cover',
    borderRadius: 14,
  },
  placeholderArtwork: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f5f7fa',
    borderRadius: 14,
  },
  playingIndicator: {
    position: 'absolute',
    bottom: 8,
    right: 8,
    backgroundColor: color.primary,
    borderRadius: 12,
    padding: 6,
    shadowColor: color.primary,
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.4,
    shadowRadius: 4,
    elevation: 4,
  },
  loadingIndicator: {
    position: 'absolute',
    bottom: 8,
    right: 8,
    backgroundColor: '#6c757d',
    borderRadius: 12,
    padding: 6,
    shadowColor: '#6c757d',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.4,
    shadowRadius: 4,
    elevation: 4,
  },
  rightSection: {
    flex: 1,
    justifyContent: 'space-between',
    paddingVertical: 4,
  },
  trackInfo: {
    flex: 1,
    justifyContent: 'center',
    paddingRight: 8,
  },
  title: {
    color: '#1a1a1a',
    fontSize: 16,
    fontWeight: '700',
    marginBottom: 6,
    lineHeight: 20,
  },
  artist: {
    color: '#666666',
    fontSize: 13,
    fontWeight: '500',
    lineHeight: 16,
  },

  currentTrackItem: {
    borderColor: color.primary,
    borderWidth: 2,
    backgroundColor: '#f8fbff',
  },
  currentTrackTitle: {
    color: color.primary,
    fontWeight: '800',
  },
  currentTrackArtist: {
    color: color.primary,
    opacity: 0.9,
    fontWeight: '600',
  },
  controlsSection: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 8,
    paddingTop: 8,
  },
  seekButton: {
    alignItems: 'center',
    justifyContent: 'center',
    width: 36,
    height: 36,
    backgroundColor: '#f8f9fa',
    borderRadius: 18,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 0.08,
    shadowRadius: 2,
    elevation: 2,
  },
  disabledButton: {
    backgroundColor: '#f0f0f0',
    shadowOpacity: 0.05,
  },
  mainPlayButton: {
    width: 48,
    height: 48,
    backgroundColor: color.primary,
    borderRadius: 24,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: color.primary,
    shadowOffset: {
      width: 0,
      height: 3,
    },
    shadowOpacity: 0.25,
    shadowRadius: 6,
    elevation: 5,
  },
  pauseButton: {
    backgroundColor: '#e74c3c',
    shadowColor: '#e74c3c',
  },
  loadingButton: {
    backgroundColor: '#6c757d',
    shadowColor: '#6c757d',
  },
  buttonIconContainer: {
    width: 24,
    height: 24,
    justifyContent: 'center',
    alignItems: 'center',
  },
  iconWrapper: {
    width: 22,
    height: 22,
    justifyContent: 'center',
    alignItems: 'center',
  },
  indicatorIconContainer: {
    width: 12,
    height: 12,
    justifyContent: 'center',
    alignItems: 'center',
  },
});

export default ListenLivePlayer;