import React, { useEffect, useState } from 'react';
import { View, Text, FlatList, ActivityIndicator, StyleSheet } from 'react-native';
import { fetchHPMPodcasts, Podcast } from '../services/podcastApi';
import { useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { PodcastStackParamList } from '../navigation/PodcastStack';
import PodcastCard from '../components/PodcastCard';
import ScreenHeader from '../components/ScreenHeader';

type PodcastScreenNavigationProp = StackNavigationProp<PodcastStackParamList, 'PodcastList'>;

const PodcastScreen = () => {
  const navigation = useNavigation<PodcastScreenNavigationProp>();
  const [podcasts, setPodcasts] = useState<Podcast[]>([]);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    fetchHPMPodcasts()
      .then(setPodcasts)
      .finally(() => setLoading(false));
  }, []);

  if (loading) {
    return <ActivityIndicator size="large" style={{ flex: 1, justifyContent: 'center' }} />;
  }

  return (
    <>
      <ScreenHeader 
        title="Podcasts"
        description="All of Houston Public Media's podcasting information, including links, content, and more"
      />
      
      <FlatList
        data={podcasts}
        keyExtractor={item => item.id.toString()}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.listContainer}
        renderItem={({ item }) => (
          <PodcastCard 
            podcast={item}
            onPress={() => navigation.navigate('PodcastDetails', { podcast: item })}
          />
        )}
      />
    </>
  );
};

const styles = StyleSheet.create({
  listContainer: {
    paddingBottom: 20,
  },
});

export default PodcastScreen;