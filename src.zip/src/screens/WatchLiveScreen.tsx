import React from 'react';
import { View, StyleSheet, Platform } from 'react-native'
import { WebView } from 'react-native-webview';
import ScreenHeader from '../components/ScreenHeader';

const WatchLiveScreen = () => {
const userAgent = Platform.OS === 'ios'
    ? 'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.0 Mobile/15E148 Safari/604.1'
    : 'Smitas Phone, Android phone, Iphone, Safari, mobile app, Chrome';

  return (
    <>
      <ScreenHeader 
        title="Watch Live"
        description="Watch Houston Public Media's live television programming and special events"
      />
      <View style={styles.container}>
        <WebView
          style={styles.webview}
          originWhitelist={["*"]}
          source={{ uri: 'https://cdn.houstonpublicmedia.org/assets/watch-live.html' }}
          javaScriptEnabled={true}
          domStorageEnabled={true}
          allowsInlineMediaPlayback={true}
          mediaPlaybackRequiresUserAction={false}
          allowsFullscreenVideo={true}
          automaticallyAdjustContentInsets={false}
          mixedContentMode="always"
          sharedCookiesEnabled={true}
          thirdPartyCookiesEnabled={true}
          setSupportMultipleWindows={true}
          onShouldStartLoadWithRequest={() => true}
          allowsProtectedMedia={true}
          scalesPageToFit={false}
          userAgent={userAgent}
        />
      </View>
    </>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1 },
  webview: { flex: 1 },
});

export default WatchLiveScreen;